# ae2-gui-light

Resource pack for Minecraft 1.21.1 inspired by [Applied-Energistics-2](https://github.com/AppliedEnergistics/Applied-Energistics-2)
